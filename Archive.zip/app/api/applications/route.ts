import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/db"
import Application from "@/models/application"
import Institution from "@/models/institution"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"
import { z } from "zod"

// Schema for application validation
const applicationSchema = z.object({
  applicantName: z.string().min(3, "Name must be at least 3 characters"),
  birthDate: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid date format",
  }),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(5, "Phone must be at least 5 characters"),
  institution: z.string().min(1, "Institution is required"),
  documents: z
    .array(
      z.object({
        name: z.string().min(1, "Document name is required"),
        url: z.string().url("Invalid URL"),
        type: z.string().min(1, "Document type is required"),
      }),
    )
    .min(1, "At least one document is required"),
})

// GET all applications (admin only) or user's applications
export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    // Check if user is authenticated
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const { searchParams } = new URL(request.url)
    const email = searchParams.get("email")
    const applicationId = searchParams.get("applicationId")
    const status = searchParams.get("status")
    const institutionId = searchParams.get("institution")

    const query: any = {}

    // If admin, allow filtering
    if (session.user.role === "admin") {
      if (email) query.email = email
      if (applicationId) query.applicationId = applicationId
      if (status) query.status = status
      if (institutionId) query.institution = institutionId
    } else {
      // Regular users can only see their own applications
      query.email = session.user.email
    }

    const applications = await Application.find(query).populate("institution", "name type").sort({ createdAt: -1 })

    return NextResponse.json(applications)
  } catch (error) {
    console.error("Error fetching applications:", error)
    return NextResponse.json({ error: "Failed to fetch applications" }, { status: 500 })
  }
}

// POST new application
export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate request body
    const validationResult = applicationSchema.safeParse(body)
    if (!validationResult.success) {
      return NextResponse.json({ error: validationResult.error.errors }, { status: 400 })
    }

    await connectToDatabase()

    // Check if institution exists
    const institution = await Institution.findById(validationResult.data.institution)
    if (!institution) {
      return NextResponse.json({ error: "Institution not found" }, { status: 404 })
    }

    // Create new application
    const newApplication = new Application({
      ...validationResult.data,
      birthDate: new Date(validationResult.data.birthDate),
      status: "pending",
    })

    await newApplication.save()

    return NextResponse.json(
      {
        success: true,
        applicationId: newApplication.applicationId,
        message: "Application submitted successfully",
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating application:", error)
    return NextResponse.json({ error: "Failed to create application" }, { status: 500 })
  }
}
